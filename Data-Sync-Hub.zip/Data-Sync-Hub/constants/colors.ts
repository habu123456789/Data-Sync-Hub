const Colors = {
  light: {
    text: "#1A1A1A",
    textSecondary: "#666666",
    background: "#F5F0EB",
    surface: "#FFFFFF",
    surfaceElevated: "#FFF8F5",
    tint: "#FF7357",
    accent: "#FF7357",
    accentGlow: "rgba(255, 115, 87, 0.3)",
    accentSoft: "rgba(255, 115, 87, 0.1)",
    border: "rgba(0, 0, 0, 0.08)",
    tabIconDefault: "#999999",
    tabIconSelected: "#FF7357",
    cardShadow: "rgba(255, 115, 87, 0.15)",
  },
  dark: {
    text: "#F5F0EB",
    textSecondary: "#A0998F",
    background: "#0D0D0D",
    surface: "#1A1A1A",
    surfaceElevated: "#242424",
    tint: "#FF7357",
    accent: "#FF7357",
    accentGlow: "rgba(255, 115, 87, 0.4)",
    accentSoft: "rgba(255, 115, 87, 0.12)",
    border: "rgba(255, 255, 255, 0.08)",
    tabIconDefault: "#666666",
    tabIconSelected: "#FF7357",
    cardShadow: "rgba(255, 115, 87, 0.2)",
  },
};

export default Colors;
