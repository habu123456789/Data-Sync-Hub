import React, { useState, useCallback } from "react";
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  TextInput,
  Pressable,
  RefreshControl,
  Platform,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery } from "@tanstack/react-query";
import { router } from "expo-router";
import { Ionicons, Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import Animated, { FadeIn, FadeInDown } from "react-native-reanimated";
import { useTheme } from "@/lib/useTheme";
import { getApiUrl } from "@/lib/query-client";
import { PostCard } from "@/components/PostCard";
import { PostCardShimmer } from "@/components/ShimmerLoader";
import type { BlogPost, BlogResponse } from "@/lib/types";

export default function HomeScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  const {
    data,
    isLoading,
    isRefetching,
    refetch,
  } = useQuery<BlogResponse>({
    queryKey: ["/api/posts"],
    staleTime: 5 * 60 * 1000,
  });

  const filteredPosts = data?.posts?.filter((post) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      post.title.toLowerCase().includes(q) ||
      post.plainText.toLowerCase().includes(q)
    );
  }) || [];

  const handleRefresh = useCallback(async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    await refetch();
  }, [refetch]);

  const handlePostPress = useCallback((post: BlogPost) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push({
      pathname: "/post/[id]",
      params: {
        id: encodeURIComponent(post.id),
        postData: JSON.stringify(post),
      },
    });
  }, []);

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  const renderHeader = () => (
    <View>
      <LinearGradient
        colors={
          isDark
            ? ["rgba(255,115,87,0.15)", "rgba(255,115,87,0.02)", "transparent"]
            : ["rgba(255,115,87,0.08)", "rgba(255,115,87,0.01)", "transparent"]
        }
        style={styles.headerGradient}
      />

      <Animated.View
        entering={FadeIn.duration(600)}
        style={[styles.header, { paddingTop: insets.top + webTopInset + 16 }]}
      >
        <View style={styles.brandRow}>
          <View
            style={[
              styles.brandIcon,
              { backgroundColor: colors.accentSoft },
            ]}
          >
            <Ionicons name="book" size={22} color={colors.accent} />
          </View>
          <View>
            <Text
              style={[
                styles.brandName,
                { color: colors.text, fontFamily: "Lora_700Bold" },
              ]}
            >
              Habu Says
            </Text>
            <Text
              style={[
                styles.brandSub,
                {
                  color: colors.textSecondary,
                  fontFamily: "OpenSans_400Regular",
                },
              ]}
            >
              Stories, Poems & Thoughts
            </Text>
          </View>
        </View>

        <View
          style={[
            styles.searchContainer,
            {
              backgroundColor: colors.surfaceElevated,
              borderColor: isSearching ? colors.accent : colors.border,
            },
          ]}
        >
          <Feather
            name="search"
            size={18}
            color={isSearching ? colors.accent : colors.textSecondary}
          />
          <TextInput
            style={[
              styles.searchInput,
              { color: colors.text, fontFamily: "OpenSans_400Regular" },
            ]}
            placeholder="Search posts..."
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            onFocus={() => setIsSearching(true)}
            onBlur={() => setIsSearching(false)}
          />
          {searchQuery.length > 0 && (
            <Pressable
              onPress={() => setSearchQuery("")}
              hitSlop={8}
            >
              <Ionicons name="close-circle" size={18} color={colors.textSecondary} />
            </Pressable>
          )}
        </View>

        {data && (
          <Animated.View entering={FadeInDown.delay(200).duration(400)}>
            <Text
              style={[
                styles.postCount,
                {
                  color: colors.textSecondary,
                  fontFamily: "OpenSans_500Medium",
                },
              ]}
            >
              {filteredPosts.length} {filteredPosts.length === 1 ? "post" : "posts"}
              {searchQuery ? " found" : " total"}
            </Text>
          </Animated.View>
        )}
      </Animated.View>
    </View>
  );

  const renderEmpty = () => {
    if (isLoading) return null;
    return (
      <Animated.View
        entering={FadeIn.duration(400)}
        style={styles.emptyContainer}
      >
        <View
          style={[
            styles.emptyIcon,
            { backgroundColor: colors.accentSoft },
          ]}
        >
          <Ionicons
            name={searchQuery ? "search" : "document-text-outline"}
            size={32}
            color={colors.accent}
          />
        </View>
        <Text
          style={[
            styles.emptyTitle,
            { color: colors.text, fontFamily: "Lora_600SemiBold" },
          ]}
        >
          {searchQuery ? "No results found" : "No posts yet"}
        </Text>
        <Text
          style={[
            styles.emptyText,
            {
              color: colors.textSecondary,
              fontFamily: "OpenSans_400Regular",
            },
          ]}
        >
          {searchQuery
            ? "Try a different search term"
            : "Pull down to refresh"}
        </Text>
      </Animated.View>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={isLoading ? [] : filteredPosts}
        keyExtractor={(item) => item.id}
        renderItem={({ item, index }) => (
          <PostCard
            post={item}
            index={index}
            onPress={() => handlePostPress(item)}
          />
        )}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={
          isLoading ? (
            <View style={styles.shimmerContainer}>
              <PostCardShimmer />
              <PostCardShimmer />
              <PostCardShimmer />
            </View>
          ) : (
            renderEmpty()
          )
        }
        ListFooterComponent={<View style={{ height: insets.bottom + (Platform.OS === "web" ? 34 : 20) }} />}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={isRefetching}
            onRefresh={handleRefresh}
            tintColor={colors.accent}
            colors={[colors.accent]}
          />
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerGradient: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 250,
  },
  header: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    gap: 16,
  },
  brandRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
  },
  brandIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  brandName: {
    fontSize: 26,
    letterSpacing: -0.5,
  },
  brandSub: {
    fontSize: 13,
    marginTop: 1,
  },
  searchContainer: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1.5,
    gap: 10,
  },
  searchInput: {
    flex: 1,
    fontSize: 15,
    padding: 0,
    margin: 0,
  },
  postCount: {
    fontSize: 13,
    paddingLeft: 4,
  },
  listContent: {
    flexGrow: 1,
  },
  shimmerContainer: {
    gap: 0,
  },
  emptyContainer: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
    gap: 12,
  },
  emptyIcon: {
    width: 64,
    height: 64,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  emptyTitle: {
    fontSize: 18,
  },
  emptyText: {
    fontSize: 14,
  },
});
