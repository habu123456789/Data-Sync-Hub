import React, { useEffect } from "react";
import { StyleSheet, View } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  interpolate,
} from "react-native-reanimated";
import { useTheme } from "@/lib/useTheme";

function ShimmerBlock({ width, height, style }: { width: number | string; height: number; style?: any }) {
  const { colors } = useTheme();
  const shimmer = useSharedValue(0);

  useEffect(() => {
    shimmer.value = withRepeat(withTiming(1, { duration: 1500 }), -1, true);
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: interpolate(shimmer.value, [0, 1], [0.3, 0.7]),
  }));

  return (
    <Animated.View
      style={[
        {
          width: width as any,
          height,
          backgroundColor: colors.surfaceElevated,
          borderRadius: 8,
        },
        style,
        animatedStyle,
      ]}
    />
  );
}

export function PostCardShimmer() {
  const { colors } = useTheme();

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
        },
      ]}
    >
      <ShimmerBlock width="100%" height={3} style={{ borderRadius: 0 }} />
      <View style={styles.content}>
        <View style={styles.meta}>
          <ShimmerBlock width={80} height={14} />
          <ShimmerBlock width={60} height={14} />
        </View>
        <ShimmerBlock width="85%" height={24} />
        <ShimmerBlock width="100%" height={16} />
        <ShimmerBlock width="70%" height={16} />
        <View style={styles.tags}>
          <ShimmerBlock width={60} height={24} style={{ borderRadius: 12 }} />
          <ShimmerBlock width={50} height={24} style={{ borderRadius: 12 }} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    overflow: "hidden",
    borderWidth: 1,
  },
  content: {
    padding: 16,
    gap: 12,
  },
  meta: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  tags: {
    flexDirection: "row",
    gap: 8,
  },
});
