import React from "react";
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  Platform,
} from "react-native";
import { Image } from "expo-image";
import { Ionicons } from "@expo/vector-icons";
import { useTheme } from "@/lib/useTheme";
import type { BlogPost } from "@/lib/types";
import Animated, {
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

interface PostCardProps {
  post: BlogPost;
  index: number;
  onPress: () => void;
}

export function PostCard({ post, index, onPress }: PostCardProps) {
  const { colors, isDark } = useTheme();
  const scale = useSharedValue(1);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  const formattedDate = new Date(post.published).toLocaleDateString("hi-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });

  const hasImage = !!post.thumbnail;

  return (
    <AnimatedPressable
      entering={FadeInDown.delay(index * 80).duration(500).springify()}
      style={[
        styles.card,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
        },
        animatedStyle,
      ]}
      onPressIn={() => {
        scale.value = withSpring(0.97, { damping: 15 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15 });
      }}
      onPress={onPress}
    >
      <View
        style={[
          styles.glowLine,
          { backgroundColor: colors.accent },
        ]}
      />

      {hasImage && (
        <Image
          source={{ uri: post.thumbnail! }}
          style={styles.thumbnail}
          contentFit="cover"
          transition={300}
        />
      )}

      <View style={styles.content}>
        <View style={styles.meta}>
          <View style={styles.authorRow}>
            <View
              style={[
                styles.authorDot,
                { backgroundColor: colors.accent },
              ]}
            />
            <Text
              style={[
                styles.author,
                { color: colors.accent, fontFamily: "OpenSans_600SemiBold" },
              ]}
            >
              {post.author}
            </Text>
          </View>
          <Text
            style={[
              styles.date,
              { color: colors.textSecondary, fontFamily: "OpenSans_400Regular" },
            ]}
          >
            {formattedDate}
          </Text>
        </View>

        <Text
          style={[
            styles.title,
            { color: colors.text, fontFamily: "Lora_600SemiBold" },
          ]}
          numberOfLines={2}
        >
          {post.title}
        </Text>

        <Text
          style={[
            styles.snippet,
            { color: colors.textSecondary, fontFamily: "OpenSans_400Regular" },
          ]}
          numberOfLines={3}
        >
          {post.snippet}
        </Text>

        {post.categories.length > 0 && (
          <View style={styles.tags}>
            {post.categories.slice(0, 3).map((cat, i) => (
              <View
                key={i}
                style={[
                  styles.tag,
                  { backgroundColor: colors.accentSoft },
                ]}
              >
                <Text
                  style={[
                    styles.tagText,
                    { color: colors.accent, fontFamily: "OpenSans_500Medium" },
                  ]}
                >
                  {cat}
                </Text>
              </View>
            ))}
          </View>
        )}

        <View style={styles.footer}>
          <View style={styles.readMore}>
            <Text
              style={[
                styles.readMoreText,
                { color: colors.accent, fontFamily: "OpenSans_600SemiBold" },
              ]}
            >
              Read more
            </Text>
            <Ionicons name="arrow-forward" size={14} color={colors.accent} />
          </View>
        </View>
      </View>
    </AnimatedPressable>
  );
}

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    marginHorizontal: 16,
    marginBottom: 16,
    overflow: "hidden",
    borderWidth: 1,
    ...Platform.select({
      ios: {
        shadowColor: "#FF7357",
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.08,
        shadowRadius: 12,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  glowLine: {
    height: 3,
    width: "100%",
    opacity: 0.8,
  },
  thumbnail: {
    width: "100%",
    height: 180,
  },
  content: {
    padding: 16,
    gap: 10,
  },
  meta: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  authorRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  authorDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  author: {
    fontSize: 12,
    textTransform: "uppercase",
    letterSpacing: 1,
  },
  date: {
    fontSize: 12,
  },
  title: {
    fontSize: 20,
    lineHeight: 28,
  },
  snippet: {
    fontSize: 14,
    lineHeight: 22,
  },
  tags: {
    flexDirection: "row",
    gap: 8,
    flexWrap: "wrap",
  },
  tag: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  tagText: {
    fontSize: 11,
    textTransform: "capitalize",
  },
  footer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    marginTop: 4,
  },
  readMore: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  readMoreText: {
    fontSize: 13,
  },
});
