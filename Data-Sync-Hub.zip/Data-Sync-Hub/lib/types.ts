export interface BlogPost {
  id: string;
  title: string;
  content: string;
  plainText: string;
  snippet: string;
  thumbnail: string | null;
  published: string;
  url: string;
  author: string;
  categories: string[];
}

export interface BlogResponse {
  posts: BlogPost[];
  totalResults: number;
}
