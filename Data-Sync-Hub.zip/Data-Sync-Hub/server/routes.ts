import type { Express, Request, Response } from "express";
import { createServer, type Server } from "node:http";

const BLOG_FEED_URL = "https://habu-says.blogspot.com/feeds/posts/default?alt=json";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/posts", async (req: Request, res: Response) => {
    try {
      const maxResults = req.query.maxResults || "50";
      const startIndex = req.query.startIndex || "1";
      const url = `${BLOG_FEED_URL}&max-results=${maxResults}&start-index=${startIndex}`;
      
      const response = await fetch(url);
      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to fetch blog posts" });
      }
      
      const data = await response.json();
      const feed = data.feed;
      
      const totalResults = parseInt(feed.openSearch$totalResults.$t, 10);
      const posts = (feed.entry || []).map((entry: any) => {
        const alternateLink = entry.link?.find((l: any) => l.rel === "alternate");
        const published = new Date(entry.published.$t);
        
        const htmlContent = entry.content?.$t || "";
        const plainText = htmlContent
          .replace(/<[^>]*>/g, " ")
          .replace(/&nbsp;/g, " ")
          .replace(/&amp;/g, "&")
          .replace(/&lt;/g, "<")
          .replace(/&gt;/g, ">")
          .replace(/&quot;/g, '"')
          .replace(/\s+/g, " ")
          .trim();
        
        const snippet = plainText.length > 150 ? plainText.substring(0, 150) + "..." : plainText;
        
        const imgMatch = htmlContent.match(/<img[^>]+src="([^"]+)"/);
        const thumbnail = imgMatch ? imgMatch[1] : null;
        
        return {
          id: entry.id.$t,
          title: entry.title.$t || "Untitled",
          content: htmlContent,
          plainText,
          snippet,
          thumbnail,
          published: published.toISOString(),
          url: alternateLink?.href || "",
          author: entry.author?.[0]?.name?.$t || "Habu",
          categories: entry.category?.map((c: any) => c.term) || [],
        };
      });
      
      res.json({ posts, totalResults });
    } catch (error) {
      console.error("Error fetching blog posts:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  app.get("/api/posts/search", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ error: "Search query is required" });
      }
      
      const url = `${BLOG_FEED_URL}&max-results=50`;
      const response = await fetch(url);
      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to fetch blog posts" });
      }
      
      const data = await response.json();
      const feed = data.feed;
      const searchLower = query.toLowerCase();
      
      const posts = (feed.entry || [])
        .map((entry: any) => {
          const alternateLink = entry.link?.find((l: any) => l.rel === "alternate");
          const published = new Date(entry.published.$t);
          
          const htmlContent = entry.content?.$t || "";
          const plainText = htmlContent
            .replace(/<[^>]*>/g, " ")
            .replace(/&nbsp;/g, " ")
            .replace(/&amp;/g, "&")
            .replace(/&lt;/g, "<")
            .replace(/&gt;/g, ">")
            .replace(/&quot;/g, '"')
            .replace(/\s+/g, " ")
            .trim();
          
          const snippet = plainText.length > 150 ? plainText.substring(0, 150) + "..." : plainText;
          const imgMatch = htmlContent.match(/<img[^>]+src="([^"]+)"/);
          const thumbnail = imgMatch ? imgMatch[1] : null;
          
          return {
            id: entry.id.$t,
            title: entry.title.$t || "Untitled",
            content: htmlContent,
            plainText,
            snippet,
            thumbnail,
            published: published.toISOString(),
            url: alternateLink?.href || "",
            author: entry.author?.[0]?.name?.$t || "Habu",
            categories: entry.category?.map((c: any) => c.term) || [],
          };
        })
        .filter((post: any) => 
          post.title.toLowerCase().includes(searchLower) || 
          post.plainText.toLowerCase().includes(searchLower)
        );
      
      res.json({ posts, totalResults: posts.length });
    } catch (error) {
      console.error("Error searching blog posts:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
