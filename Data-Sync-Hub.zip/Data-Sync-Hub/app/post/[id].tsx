import React, { useCallback, useRef } from "react";
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Pressable,
  Platform,
  Share,
  useWindowDimensions,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons, Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import * as Haptics from "expo-haptics";
import * as WebBrowser from "expo-web-browser";
import Animated, { FadeIn, FadeInDown, FadeInUp } from "react-native-reanimated";
import { useTheme } from "@/lib/useTheme";
import type { BlogPost } from "@/lib/types";

function parseHtmlToBlocks(html: string): string[] {
  const blocks: string[] = [];
  const cleaned = html
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>/gi, "\n\n")
    .replace(/<\/div>/gi, "\n")
    .replace(/<[^>]*>/g, "")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");

  const lines = cleaned.split(/\n+/).map((l) => l.trim()).filter(Boolean);
  return lines;
}

export default function PostDetailScreen() {
  const { colors, isDark } = useTheme();
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const params = useLocalSearchParams<{ id: string; postData: string }>();

  const post: BlogPost | null = params.postData
    ? JSON.parse(params.postData)
    : null;

  const webTopInset = Platform.OS === "web" ? 67 : 0;

  if (!post) {
    return (
      <View
        style={[
          styles.container,
          {
            backgroundColor: colors.background,
            justifyContent: "center",
            alignItems: "center",
          },
        ]}
      >
        <Text style={[styles.errorText, { color: colors.text }]}>
          Post not found
        </Text>
        <Pressable onPress={() => router.back()}>
          <Text style={[styles.backLink, { color: colors.accent }]}>
            Go back
          </Text>
        </Pressable>
      </View>
    );
  }

  const contentBlocks = parseHtmlToBlocks(post.content);

  const formattedDate = new Date(post.published).toLocaleDateString("hi-IN", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const handleShare = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    try {
      await Share.share({
        message: `${post.title}\n\n${post.snippet}\n\nRead more: ${post.url}`,
        url: post.url,
      });
    } catch (e) {}
  };

  const handleOpenOriginal = async () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    try {
      await WebBrowser.openBrowserAsync(post.url);
    } catch (e) {}
  };

  const handleBack = () => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.back();
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <View
        style={[
          styles.topBar,
          {
            paddingTop: insets.top + webTopInset + 8,
            backgroundColor: isDark
              ? "rgba(13,13,13,0.9)"
              : "rgba(245,240,235,0.9)",
          },
        ]}
      >
        <Pressable
          onPress={handleBack}
          style={[styles.iconBtn, { backgroundColor: colors.surfaceElevated }]}
          hitSlop={8}
        >
          <Ionicons name="chevron-back" size={22} color={colors.text} />
        </Pressable>

        <View style={styles.topBarActions}>
          <Pressable
            onPress={handleShare}
            style={[
              styles.iconBtn,
              { backgroundColor: colors.surfaceElevated },
            ]}
            hitSlop={8}
          >
            <Feather name="share" size={18} color={colors.text} />
          </Pressable>
          <Pressable
            onPress={handleOpenOriginal}
            style={[
              styles.iconBtn,
              { backgroundColor: colors.surfaceElevated },
            ]}
            hitSlop={8}
          >
            <Feather name="external-link" size={18} color={colors.text} />
          </Pressable>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: insets.top + webTopInset + 60,
            paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 40),
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <LinearGradient
          colors={
            isDark
              ? [
                  "rgba(255,115,87,0.12)",
                  "rgba(255,115,87,0.03)",
                  "transparent",
                ]
              : [
                  "rgba(255,115,87,0.06)",
                  "rgba(255,115,87,0.01)",
                  "transparent",
                ]
          }
          style={styles.topGradient}
        />

        <Animated.View
          entering={FadeInDown.duration(500)}
          style={styles.titleSection}
        >
          <View style={styles.metaRow}>
            <View
              style={[styles.accentDot, { backgroundColor: colors.accent }]}
            />
            <Text
              style={[
                styles.authorText,
                { color: colors.accent, fontFamily: "OpenSans_600SemiBold" },
              ]}
            >
              {post.author}
            </Text>
          </View>

          <Text
            style={[
              styles.title,
              { color: colors.text, fontFamily: "Lora_700Bold" },
            ]}
          >
            {post.title}
          </Text>

          <Text
            style={[
              styles.dateText,
              {
                color: colors.textSecondary,
                fontFamily: "OpenSans_400Regular",
              },
            ]}
          >
            {formattedDate}
          </Text>

          {post.categories.length > 0 && (
            <View style={styles.categories}>
              {post.categories.map((cat, i) => (
                <View
                  key={i}
                  style={[
                    styles.categoryChip,
                    { backgroundColor: colors.accentSoft },
                  ]}
                >
                  <Text
                    style={[
                      styles.categoryText,
                      {
                        color: colors.accent,
                        fontFamily: "OpenSans_500Medium",
                      },
                    ]}
                  >
                    {cat}
                  </Text>
                </View>
              ))}
            </View>
          )}
        </Animated.View>

        <View
          style={[
            styles.divider,
            { backgroundColor: colors.accent, opacity: 0.3 },
          ]}
        />

        <Animated.View
          entering={FadeIn.delay(200).duration(600)}
          style={styles.contentSection}
        >
          {contentBlocks.map((block, i) => (
            <Text
              key={i}
              style={[
                styles.contentText,
                { color: colors.text, fontFamily: "Lora_400Regular" },
              ]}
            >
              {block}
            </Text>
          ))}
        </Animated.View>

        <Animated.View
          entering={FadeInUp.delay(400).duration(500)}
          style={styles.bottomActions}
        >
          <Pressable
            onPress={handleOpenOriginal}
            style={[
              styles.originalBtn,
              {
                backgroundColor: colors.accent,
              },
            ]}
          >
            <Feather name="external-link" size={16} color="#fff" />
            <Text style={[styles.originalBtnText, { fontFamily: "OpenSans_600SemiBold" }]}>
              View Original
            </Text>
          </Pressable>

          <Pressable
            onPress={handleShare}
            style={[
              styles.shareBtn,
              {
                borderColor: colors.accent,
              },
            ]}
          >
            <Feather name="share-2" size={16} color={colors.accent} />
            <Text
              style={[
                styles.shareBtnText,
                { color: colors.accent, fontFamily: "OpenSans_600SemiBold" },
              ]}
            >
              Share
            </Text>
          </Pressable>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  topBar: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  topBarActions: {
    flexDirection: "row",
    gap: 8,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  topGradient: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    height: 300,
  },
  titleSection: {
    gap: 12,
    marginBottom: 20,
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  accentDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  authorText: {
    fontSize: 13,
    textTransform: "uppercase",
    letterSpacing: 1.5,
  },
  title: {
    fontSize: 28,
    lineHeight: 38,
    letterSpacing: -0.5,
  },
  dateText: {
    fontSize: 13,
  },
  categories: {
    flexDirection: "row",
    gap: 8,
    flexWrap: "wrap",
  },
  categoryChip: {
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 14,
  },
  categoryText: {
    fontSize: 12,
    textTransform: "capitalize",
  },
  divider: {
    height: 2,
    width: 60,
    borderRadius: 1,
    marginBottom: 24,
  },
  contentSection: {
    gap: 16,
    marginBottom: 40,
  },
  contentText: {
    fontSize: 17,
    lineHeight: 30,
    letterSpacing: 0.2,
  },
  bottomActions: {
    flexDirection: "row",
    gap: 12,
    marginBottom: 20,
  },
  originalBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
  },
  originalBtnText: {
    color: "#fff",
    fontSize: 14,
  },
  shareBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1.5,
  },
  shareBtnText: {
    fontSize: 14,
  },
  errorText: {
    fontSize: 18,
    fontFamily: "Lora_600SemiBold",
    marginBottom: 12,
  },
  backLink: {
    fontSize: 15,
    fontFamily: "OpenSans_600SemiBold",
  },
});
